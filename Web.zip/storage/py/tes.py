import time

print("START")
for i in range(10):
    print("CHECK", i * 10, "%")
print("DONE")
