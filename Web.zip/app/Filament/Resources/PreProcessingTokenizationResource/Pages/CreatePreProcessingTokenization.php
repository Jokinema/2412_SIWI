<?php

namespace App\Filament\Resources\PreProcessingTokenizationResource\Pages;

use App\Filament\Resources\PreProcessingTokenizationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePreProcessingTokenization extends CreateRecord
{
    protected static string $resource = PreProcessingTokenizationResource::class;
}
