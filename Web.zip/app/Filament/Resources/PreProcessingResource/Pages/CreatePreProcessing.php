<?php

namespace App\Filament\Resources\PreProcessingResource\Pages;

use App\Filament\Resources\PreProcessingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePreProcessing extends CreateRecord
{
    protected static string $resource = PreProcessingResource::class;
}
