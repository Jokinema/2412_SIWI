<?php

namespace App\Filament\Resources\PembobotanKataKeteranganResource\Pages;

use App\Filament\Resources\PembobotanKataKeteranganResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePembobotanKataKeterangan extends CreateRecord
{
    protected static string $resource = PembobotanKataKeteranganResource::class;
}
