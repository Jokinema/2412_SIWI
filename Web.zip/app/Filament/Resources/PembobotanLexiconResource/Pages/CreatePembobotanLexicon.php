<?php

namespace App\Filament\Resources\PembobotanLexiconResource\Pages;

use App\Filament\Resources\PembobotanLexiconResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePembobotanLexicon extends CreateRecord
{
    protected static string $resource = PembobotanLexiconResource::class;
}
